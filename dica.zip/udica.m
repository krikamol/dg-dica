function [V,D,X,Xt] = udica(K, Kt, groupIdx, lambda, M)
% udica - unsupervised domain-invariant component analysis
%
% Synopsis
%   [V,D,X,Xt] = udica(K, Kt, groupIdx, lambda, M)
%
% Description
%   Unsupervised domain-invariant component analysis (UDICA) finds a low dimensional
%   subspace of data points from several distributions so as to minimize the
%   variance among the distributions of projected data points.
% 
%
% Inputs ([]s are optional)
%   (matrix) K          NxN kernel matrix between data points
%   (matrix) Kt         NtxN kernel matrix between test data and training data
%   (vector) groupIdx   Nx1 vector of group membership of data points
%   (scalar) lambda     The regularization parameter
%   (scalar) M          The dimensionality of subspace (M < N)
%
% Outputs ([]s are optional)
%   (matrix) V          Nxdim matrix in which each column is the
%                       eigenvector
%   (matrix) D          MxM diagonal matrix in which the diagonal elements
%                       are eigenvalues associated with the eigenvectors in
%                       the matrix V
%   (matrix) X          MxN matrix in which each column is the projection
%                       of original data point onto the subspace spanned by
%                       the eigenvectors in the matrix V
%   (matrix) Xt         MxNt matrix in which each column is the projection
%                       of test data point onto the subspace spanned by
%                       the eigenvectors in the matrix V
%
% Examples
%   <Example Code>
%
% See also
%   <See Also Function Name>
%
% Requirements
%   eigs (MATLAB)

% References
%   K. Muandet, D.Balduzzi,and B.Sch�lkopf, Domain Generalization via 
%   Invariant Feature Representation. The 30th International Conference on 
%   Machine Learning (ICML 2013), pages 10?18, Atlanta, Georgia.
%
% Authors
%   Krikamol Muandet <krikamol@tuebingen.mpg.de>
%
% License
%   The code can only be used for academic and research purposes.
%
% Changes
%   27/01/2012  First Edition
%   ...

if size(K,1) ~= size(K,2)
    error('K must be a symmetric matrix.');
end

N = size(K,1);                      % number of data points
uniqueGroupIdx = unique(groupIdx);  % unique group indexes
G = length(uniqueGroupIdx);         % number of groups
NG = hist(groupIdx,uniqueGroupIdx); % number of data points in each group

H = eye(N) - ones(N)./N;            % centering matrix

% construct the L matrix
L = zeros(N,N);
for i=1:N
    for j=1:N
        if groupIdx(i) == groupIdx(j)
            groupSize = NG(uniqueGroupIdx == groupIdx(i));
            L(i,j) = 1/(G*groupSize*groupSize) - 1/(G*G*groupSize*groupSize);
        else
            groupSize_i = NG(uniqueGroupIdx == groupIdx(i));
            groupSize_j = NG(uniqueGroupIdx == groupIdx(j));
            L(i,j) = - 1/(G*G*groupSize_i*groupSize_j);
        end
    end
end

% perform eigendecomposition (this step can be improved for efficiency)
K = H*K*H;

B = K*L*K + K + lambda.*eye(N);
A = K*K;

[V,D] = eigs(A,B,M);
for i=1:M
  V(:,i) = V(:,i)/(sqrt(D(i,i)));
end

% projection of data points
X = V'*K;

if ~isempty(Kt)
    Ht = eye(size(Kt,1)) - ones(size(Kt,1))./size(Kt,1);
    Kt = Ht*Kt*H;
    Xt  = V'*Kt';
else
    Xt = [];
end

end
